import { SlideContainer } from '../SlideContainer';
import { motion } from 'motion/react';
import { MessageSquare, Bot, CheckSquare } from 'lucide-react';

export function Slide7() {
  return (
    <SlideContainer background="dark">
      <div className="space-y-5">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl text-white text-center"
        >
          <span className="text-blue-400">Interação com Agent de IA:</span> Análise de Código
        </motion.h2>

        {/* Conversa */}
        <div className="grid grid-cols-2 gap-4">
          {/* Pergunta do usuário */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-3"
          >
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare className="w-5 h-5 text-green-400" />
              <span className="text-green-400">Paulo Eugenio:</span>
            </div>
            
            <div className="bg-green-900/20 border border-green-500/50 rounded-lg p-4">
              <p className="text-slate-200 italic">
                "Verifique os projetos <code className="text-green-300 bg-slate-800 px-2 py-1 rounded">PNE.Functions/src</code> e me diga se tem algo que precisamos melhorar"
              </p>
            </div>
          </motion.div>

          {/* Resposta da IA */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-3"
          >
            <div className="flex items-center gap-2 mb-2">
              <Bot className="w-5 h-5 text-blue-400" />
              <span className="text-blue-400">IA Agent:</span>
            </div>
            
            <div className="bg-blue-900/20 border border-blue-500/50 rounded-lg p-4 space-y-2">
              <p className="text-slate-200 text-sm">
                Com certeza. Fiz uma verificação final em todos os projetos em <code className="text-blue-300 bg-slate-800 px-1 rounded text-xs">PNE.Functions/src</code>.
              </p>
              <p className="text-slate-300 text-sm">
                O estado geral do código é muito bom e robusto. No entanto, identifiquei <span className="text-yellow-400">dois pontos importantes</span> de melhoria:
              </p>
              <div className="bg-slate-800/50 rounded p-3 mt-2">
                <p className="text-amber-300 text-sm">
                  <span className="text-red-400">⚠️</span> <strong>1. Lógica de Retentativa (Retry)</strong>
                </p>
                <p className="text-slate-400 text-xs mt-1">
                  Funções RabbitMQ em IntegracaoRota podem não funcionar como esperado
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Checklist de Roteiros */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-6"
        >
          <div className="bg-gradient-to-r from-purple-900/40 to-indigo-900/40 border border-purple-500/50 rounded-lg p-5">
            <div className="flex items-center gap-3 mb-4">
              <CheckSquare className="w-6 h-6 text-purple-400" />
              <h3 className="text-xl text-purple-300">
                Agents podem seguir <strong>CHECKLISTS / ROTEIROS</strong>
              </h3>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Coluna 1: Documentação */}
              <div className="bg-slate-900/50 border border-slate-700 rounded-lg p-4 space-y-2">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">📚</span>
                  <h4 className="text-blue-300">DOCUMENTAÇÃO (OBRIGATÓRIO)</h4>
                </div>
                <div className="space-y-1 text-sm">
                  <div className="flex items-start gap-2">
                    <span className="text-green-400 mt-1">☑</span>
                    <span className="text-slate-300"><strong>README.md:</strong> Adicionar nova entrada</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-green-400 mt-1">☑</span>
                    <span className="text-slate-300"><strong>docs/architecture.md:</strong> Atualizar evolução técnica</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-green-400 mt-1">☑</span>
                    <span className="text-slate-300"><strong>docs/README.md:</strong> Atualizar estrutura</span>
                  </div>
                </div>
              </div>

              {/* Coluna 2: Versionamento */}
              <div className="bg-slate-900/50 border border-slate-700 rounded-lg p-4 space-y-2">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">☁️</span>
                  <h4 className="text-emerald-300">VERSIONAMENTO GIT/GITHUB</h4>
                </div>
                <div className="space-y-1 text-sm">
                  <div className="flex items-start gap-2">
                    <span className="text-green-400 mt-1">☑</span>
                    <code className="text-cyan-300 bg-slate-800 px-2 py-0.5 rounded text-xs">git add .</code>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-green-400 mt-1">☑</span>
                    <code className="text-cyan-300 bg-slate-800 px-2 py-0.5 rounded text-xs">git commit -m "mensagem"</code>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-green-400 mt-1">☑</span>
                    <code className="text-cyan-300 bg-slate-800 px-2 py-0.5 rounded text-xs">git push</code>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-green-400 mt-1">☑</span>
                    <span className="text-slate-300">Confirmar repositório atualizado</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 bg-indigo-900/30 border border-indigo-500/40 rounded p-3">
              <p className="text-center text-indigo-200 text-sm">
                <span className="text-yellow-300">💡</span> Agents seguem esses roteiros <strong>automaticamente</strong>, garantindo consistência e qualidade
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </SlideContainer>
  );
}
