import { SlideContainer } from '../SlideContainer';
import { motion } from 'motion/react';
import { Box, Github, Sparkles } from 'lucide-react';

export function Slide2() {
  const tools = [
    { name: 'GitHub Copilot', desc: 'AI pair programming', icon: Github, color: 'from-purple-500 to-pink-500' },
    { name: 'OpenAI Codex', desc: 'Natural language to code', icon: Sparkles, color: 'from-green-500 to-emerald-500' },
    { name: 'VS Code', desc: 'Integrated development', icon: Box, color: 'from-blue-500 to-cyan-500' },
  ];

  return (
    <SlideContainer background="dark">
      <div className="space-y-12">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-5xl text-white text-center"
        >
          Ferramentas <span className="text-blue-400">Utilizadas</span>
        </motion.h2>

        <div className="grid grid-cols-3 gap-8">
          {tools.map((tool, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-opacity blur-xl rounded-xl" 
                   style={{ background: `linear-gradient(to right, var(--tw-gradient-stops))` }} />
              
              <div className="relative bg-slate-800 border border-slate-700 rounded-xl p-8 hover:border-blue-500/50 transition-colors">
                <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${tool.color} flex items-center justify-center mb-4`}>
                  <tool.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl text-white mb-2">{tool.name}</h3>
                <p className="text-slate-400">{tool.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </SlideContainer>
  );
}
