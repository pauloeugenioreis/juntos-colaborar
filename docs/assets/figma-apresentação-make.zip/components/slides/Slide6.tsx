import { SlideContainer } from '../SlideContainer';
import { motion } from 'motion/react';
import { MessageSquare, Sparkles, CheckCircle2, Zap } from 'lucide-react';

export function Slide6() {
  const benefits = [
    {
      icon: Zap,
      title: 'Velocidade',
      description: 'De horas para minutos',
      color: 'from-yellow-500 to-orange-500'
    },
    {
      icon: CheckCircle2,
      title: 'Qualidade',
      description: 'Código seguindo padrões',
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: Sparkles,
      title: 'Aprendizado',
      description: 'Melhores práticas aplicadas',
      color: 'from-purple-500 to-pink-500'
    }
  ];

  return (
    <SlideContainer background="gradient">
      <div className="space-y-10">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl text-white text-center"
        >
          Por que usar <span className="text-blue-400">Agents de IA</span>?
        </motion.h2>

        <div className="grid grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 + index * 0.1 }}
              className="relative group"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${benefit.color} opacity-20 rounded-2xl blur-xl group-hover:blur-2xl transition-all`} />
              <div className="relative bg-slate-900/80 backdrop-blur border border-slate-700 group-hover:border-slate-500 rounded-2xl p-8">
                <div className={`w-20 h-20 rounded-full bg-gradient-to-br ${benefit.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <benefit.icon className="w-10 h-10 text-white" />
                </div>
                
                <h3 className="text-3xl text-white mb-4">{benefit.title}</h3>
                <p className="text-xl text-slate-400">{benefit.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="flex items-center justify-center gap-4 bg-gradient-to-r from-blue-900/30 to-purple-900/30 border border-blue-500/50 rounded-xl p-6"
        >
          <MessageSquare className="w-8 h-8 text-blue-400" />
          <p className="text-2xl text-slate-200">
            Transforme sua forma de desenvolver software
          </p>
        </motion.div>
      </div>
    </SlideContainer>
  );
}
