import { SlideContainer } from '../SlideContainer';
import { motion } from 'motion/react';
import { Code, Users, Sparkles } from 'lucide-react';

export function Slide4() {
  const features = [
    {
      icon: Code,
      title: 'Geração de Código',
      description: 'Functions, APIs, serviços completos',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Users,
      title: 'Refatoração',
      description: 'Modernização e otimização',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Sparkles,
      title: 'Modularização',
      description: 'Padrões enterprise automáticos',
      color: 'from-green-500 to-emerald-500'
    }
  ];

  return (
    <SlideContainer background="gradient">
      <div className="space-y-8">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl text-white text-center"
        >
          O que os <span className="text-blue-400">Agents</span> podem fazer?
        </motion.h2>

        <div className="grid grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-xl group-hover:blur-2xl transition-all" />
              <div className="relative bg-slate-900/80 backdrop-blur border border-slate-700 group-hover:border-blue-500/50 rounded-xl p-8 transition-all">
                <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-2xl text-white mb-3">{feature.title}</h3>
                <p className="text-slate-400">{feature.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border border-blue-500/50 rounded-xl p-6 text-center"
        >
          <p className="text-xl text-slate-200">
            <span className="text-blue-400">Tudo isso</span> seguindo boas práticas e padrões de mercado
          </p>
        </motion.div>
      </div>
    </SlideContainer>
  );
}
