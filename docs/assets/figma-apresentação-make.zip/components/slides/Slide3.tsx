import { SlideContainer } from "../SlideContainer";
import { motion } from "motion/react";
import {
  AlertTriangle,
  Cloud,
  ArrowRight,
  Database,
  MessageSquare,
  HardDrive,
  Zap,
} from "lucide-react";

export function Slide3() {
  return (
    <SlideContainer background="gradient">
      <div className="space-y-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4"
        >
          <AlertTriangle className="w-12 h-12 text-yellow-400" />
          <h2 className="text-5xl text-white">
            Problema{" "}
            <span className="text-yellow-400">Real</span> - Migração de Nuvem → PNE Functions
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="bg-yellow-900/30 border-l-4 border-yellow-500 rounded-lg px-6 py-3"
        >
          <p className="text-yellow-200 text-lg">
            ⚠️ A mudança de nuvem exige o <strong>desacoplamento de tecnologias</strong> disponíveis apenas no ambiente Azure
          </p>
        </motion.div>

        <div className="grid grid-cols-2 gap-8">
          {/* Coluna da Esquerda - Migrações */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <h3 className="text-2xl text-cyan-400 flex items-center gap-2">
              <Cloud className="w-6 h-6" />
              Migrações necessárias
            </h3>

            <div className="space-y-3">
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-slate-900/80 border border-blue-500/30 rounded-lg p-4"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-red-400">
                    Azure - Function App
                  </span>
                  <ArrowRight className="w-4 h-4 text-green-400" />
                  <span className="text-green-400">GKE</span>
                </div>
                <p className="text-xs text-slate-400">
                  Google Kubernetes Engine
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-slate-900/80 border border-purple-500/30 rounded-lg p-4"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-purple-400" />
                  <span className="text-purple-400">KEDA</span>
                </div>
                <p className="text-xs text-slate-400">
                  Kubernetes Event-Driven Autoscaling
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-slate-900/80 border border-orange-500/30 rounded-lg p-4"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-red-400 flex items-center gap-1">
                    <MessageSquare className="w-4 h-4" />{" "}
                    Service Bus
                  </span>
                  <ArrowRight className="w-4 h-4 text-green-400" />
                  <span className="text-green-400">
                    RabbitMQ
                  </span>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 }}
                className="bg-slate-900/80 border border-green-500/30 rounded-lg p-4"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-red-400 flex items-center gap-1">
                    <Database className="w-4 h-4" /> Azure
                    Tables
                  </span>
                  <ArrowRight className="w-4 h-4 text-green-400" />
                  <span className="text-green-400">
                    MongoDB
                  </span>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 }}
                className="bg-slate-900/80 border border-cyan-500/30 rounded-lg p-4"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-red-400 flex items-center gap-1">
                    <HardDrive className="w-4 h-4" /> Azure
                    Storage
                  </span>
                  <ArrowRight className="w-4 h-4 text-green-400" />
                  <span className="text-green-400">
                    GCS Buckets
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Google Cloud Storage
                </p>
              </motion.div>
            </div>
          </motion.div>

          {/* Coluna da Direita - Desafios */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-4"
          >
            <h3 className="text-2xl text-red-400 flex items-center gap-2">
              <AlertTriangle className="w-6 h-6" />
              Desafios
            </h3>

            <div className="space-y-3">
              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-red-900/20 border border-red-500/50 rounded-lg p-4"
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">🎓</span>
                  <div>
                    <p className="text-white">
                      Conhecimento próximo de{" "}
                      <strong>zero</strong>
                    </p>
                    <p className="text-sm text-slate-400 mt-1">
                      em Kubernetes e KEDA
                    </p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 }}
                className="bg-orange-900/20 border border-orange-500/50 rounded-lg p-4"
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">💻</span>
                  <div>
                    <p className="text-white">
                      Simular ambiente local
                    </p>
                    <p className="text-sm text-slate-400 mt-1">
                      MongoDB + RabbitMQ + KEDA + K8s
                    </p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 }}
                className="bg-yellow-900/20 border border-yellow-500/50 rounded-lg p-4"
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">🔧</span>
                  <div>
                    <p className="text-white">
                      Setup multiplataforma
                    </p>
                    <p className="text-sm text-slate-400 mt-1">
                      Windows + Linux compatível
                    </p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 }}
                className="bg-purple-900/20 border border-purple-500/50 rounded-lg p-4"
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">♻️</span>
                  <div>
                    <p className="text-white">
                      Refatoração completa
                    </p>
                    <p className="text-sm text-slate-400 mt-1">
                      Migração de Azure Functions
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </SlideContainer>
  );
}