import { SlideContainer } from "../SlideContainer";
import { motion } from "motion/react";
import {
  AlertTriangle,
  Cloud,
  ArrowRight,
  Database,
  MessageSquare,
  HardDrive,
  Zap,
} from "lucide-react";

export function Slide3() {
  return (
    <SlideContainer background="gradient">
      <div className="space-y-3 px-8 max-w-7xl mx-auto py-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2"
        >
          <AlertTriangle className="w-7 h-7 text-yellow-400 flex-shrink-0" />
          <h2 className="text-2xl text-white">
            Problema{" "}
            <span className="text-yellow-400">Real</span> - Migração de Nuvem → PNE Functions
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="bg-yellow-900/30 border-l-4 border-yellow-500 rounded px-4 py-2"
        >
          <p className="text-yellow-200 text-sm">
            ⚠️ A mudança de nuvem exige o <strong>desacoplamento de tecnologias</strong> disponíveis apenas no ambiente Azure
          </p>
        </motion.div>

        <div className="grid grid-cols-2 gap-4">
          {/* Coluna da Esquerda - Migrações */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-2"
          >
            <h3 className="text-base text-cyan-400 flex items-center gap-1.5">
              <Cloud className="w-4 h-4" />
              Migrações necessárias
            </h3>

            <div className="space-y-1.5">
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-slate-900/80 border border-blue-500/30 rounded p-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-red-400 text-xs">
                    Azure - Function App
                  </span>
                  <ArrowRight className="w-3 h-3 text-green-400" />
                  <span className="text-green-400 text-xs">GKE</span>
                </div>
                <p className="text-xs text-slate-400">
                  Google Kubernetes Engine
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-slate-900/80 border border-purple-500/30 rounded p-2"
              >
                <div className="flex items-center gap-1.5 mb-0.5">
                  <Zap className="w-3 h-3 text-purple-400" />
                  <span className="text-purple-400 text-xs">KEDA</span>
                </div>
                <p className="text-xs text-slate-400">
                  Kubernetes Event-Driven Autoscaling
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-slate-900/80 border border-orange-500/30 rounded p-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-red-400 flex items-center gap-1 text-xs">
                    <MessageSquare className="w-3 h-3" />{" "}
                    Service Bus
                  </span>
                  <ArrowRight className="w-3 h-3 text-green-400" />
                  <span className="text-green-400 text-xs">
                    RabbitMQ
                  </span>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 }}
                className="bg-slate-900/80 border border-green-500/30 rounded p-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-red-400 flex items-center gap-1 text-xs">
                    <Database className="w-3 h-3" /> Azure
                    Tables
                  </span>
                  <ArrowRight className="w-3 h-3 text-green-400" />
                  <span className="text-green-400 text-xs">
                    MongoDB
                  </span>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 }}
                className="bg-slate-900/80 border border-cyan-500/30 rounded p-2"
              >
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-red-400 flex items-center gap-1 text-xs">
                    <HardDrive className="w-3 h-3" /> Azure
                    Storage
                  </span>
                  <ArrowRight className="w-3 h-3 text-green-400" />
                  <span className="text-green-400 text-xs">
                    GCS Buckets
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Google Cloud Storage
                </p>
              </motion.div>
            </div>
          </motion.div>

          {/* Coluna da Direita - Desafios */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-2"
          >
            <h3 className="text-base text-red-400 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              Desafios
            </h3>

            <div className="space-y-1.5">
              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-red-900/20 border border-red-500/50 rounded p-2"
              >
                <div className="flex items-start gap-1.5">
                  <span className="text-base leading-none">🎓</span>
                  <div>
                    <p className="text-white text-xs">
                      Conhecimento próximo de{" "}
                      <strong>zero</strong>
                    </p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      em Kubernetes e KEDA
                    </p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 }}
                className="bg-orange-900/20 border border-orange-500/50 rounded p-2"
              >
                <div className="flex items-start gap-1.5">
                  <span className="text-base leading-none">💻</span>
                  <div>
                    <p className="text-white text-xs">
                      Simular ambiente local
                    </p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      MongoDB + RabbitMQ + KEDA + K8s
                    </p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 }}
                className="bg-yellow-900/20 border border-yellow-500/50 rounded p-2"
              >
                <div className="flex items-start gap-1.5">
                  <span className="text-base leading-none">🔧</span>
                  <div>
                    <p className="text-white text-xs">
                      Setup multiplataforma
                    </p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Windows + Linux compatível
                    </p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 }}
                className="bg-purple-900/20 border border-purple-500/50 rounded p-2"
              >
                <div className="flex items-start gap-1.5">
                  <span className="text-base leading-none">♻️</span>
                  <div>
                    <p className="text-white text-xs">
                      Refatoração completa
                    </p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Migração de Azure Functions
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </SlideContainer>
  );
}
