import { SlideContainer } from '../SlideContainer';
import { motion } from 'motion/react';
import { TrendingUp, Clock, Users, Rocket } from 'lucide-react';

export function Slide8() {
  const gains = [
    { 
      icon: Rocket, 
      title: 'Setup com 1 comando', 
      desc: 'De horas para minutos',
      color: 'from-blue-500 to-cyan-500'
    },
    { 
      icon: Users, 
      title: 'Curva de aprendizado', 
      desc: 'Onboarding facilitado',
      color: 'from-purple-500 to-pink-500'
    },
    { 
      icon: TrendingUp, 
      title: 'Produtividade', 
      desc: 'Mais features, menos bugs',
      color: 'from-green-500 to-emerald-500'
    },
  ];

  return (
    <SlideContainer background="gradient">
      <div className="space-y-12">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl text-white text-center"
        >
          Ganhos <span className="text-green-400">reais</span>
        </motion.h2>

        <div className="grid grid-cols-3 gap-8">
          {gains.map((gain, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ delay: index * 0.15, type: 'spring', stiffness: 200 }}
              className="relative group"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${gain.color} opacity-0 group-hover:opacity-20 transition-opacity rounded-xl blur-xl`} />
              
              <div className="relative bg-slate-900/80 backdrop-blur border border-slate-700 rounded-xl p-8 hover:border-slate-500 transition-colors">
                <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${gain.color} flex items-center justify-center mb-4`}>
                  <gain.icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-2xl text-white mb-2">{gain.title}</h3>
                <p className="text-slate-400">{gain.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="bg-green-500/10 border border-green-500/30 rounded-lg p-6 text-center"
        >
          <p className="text-xl text-green-400">
            "A IA não substitui o desenvolvedor. Ela amplifica suas capacidades."
          </p>
        </motion.div>
      </div>
    </SlideContainer>
  );
}
