import { SlideContainer } from "../SlideContainer";
import { motion, AnimatePresence } from "motion/react";
import {
  PlayCircle,
  Terminal,
  Maximize2,
  X,
} from "lucide-react";
import { useState, useRef, useEffect } from "react";

export function Slide5() {
  const [isExpanded, setIsExpanded] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const modalVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = 2.0;
    }
  }, []);

  useEffect(() => {
    if (isExpanded && modalVideoRef.current) {
      modalVideoRef.current.playbackRate = 2.0;
    }
  }, [isExpanded]);

  return (
    <SlideContainer background="dark">
      <div className="space-y-4 px-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-center gap-2"
        >
          <PlayCircle className="w-7 h-7 text-cyan-400" />
          <h2 className="text-2xl text-white text-center">
            <span className="text-cyan-400">Demonstração:</span>{" "}
            Script de Setup Automático
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex flex-col items-center gap-3"
        >
          <div className="bg-slate-900/50 border border-cyan-500/50 rounded-lg overflow-hidden shadow-2xl shadow-cyan-500/20 w-full max-w-2xl">
            <div className="bg-slate-800 px-4 py-2 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-cyan-400" />
                <span className="text-slate-300 text-sm">
                  Execução do ambiente local - Minikube DevOps
                </span>
              </div>
              <button
                onClick={() => setIsExpanded(true)}
                className="flex items-center gap-1.5 px-2 py-1 bg-slate-700/50 hover:bg-slate-700 border border-slate-600 hover:border-cyan-500 rounded text-slate-300 hover:text-cyan-400 transition-all"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span className="text-xs">Expandir</span>
              </button>
            </div>

            <div className="bg-black p-3">
              <video
                ref={videoRef}
                className="w-full h-64 rounded border border-slate-700 object-cover"
                controls
                loop
                muted
                autoPlay
              >
                <source
                  src="https://raw.githubusercontent.com/pauloeugenioreis/minikube-devops/main/minikube/docs/assets/autostart.webm"
                  type="video/webm"
                />
                Seu navegador não suporta vídeos WebM.
              </video>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="grid grid-cols-3 gap-3 w-full max-w-2xl"
          >
            <div className="bg-blue-900/30 border border-blue-500/50 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xl">⚙️</span>
                <h3 className="text-blue-300 text-sm">
                  Instalação
                </h3>
              </div>
              <p className="text-xs text-slate-400">
                Kubernetes, KEDA, RabbitMQ, MongoDB
              </p>
            </div>

            <div className="bg-purple-900/30 border border-purple-500/50 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xl">🚀</span>
                <h3 className="text-purple-300 text-sm">
                  Inicialização
                </h3>
              </div>
              <p className="text-xs text-slate-400">
                Todos os serviços automaticamente
              </p>
            </div>

            <div className="bg-green-900/30 border border-green-500/50 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xl">✅</span>
                <h3 className="text-green-300 text-sm">
                  Validação
                </h3>
              </div>
              <p className="text-xs text-slate-400">
                Health checks e configurações
              </p>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Modal de Vídeo Expandido */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-8"
            onClick={() => setIsExpanded(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-6xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="bg-slate-900 border border-cyan-500/50 rounded-lg overflow-hidden shadow-2xl">
                <div className="bg-slate-800 px-6 py-4 border-b border-slate-700 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Terminal className="w-5 h-5 text-cyan-400" />
                    <span className="text-slate-300">
                      Execução do ambiente local - Minikube
                      DevOps
                    </span>
                  </div>
                  <button
                    onClick={() => setIsExpanded(false)}
                    className="flex items-center justify-center w-8 h-8 bg-slate-700/50 hover:bg-slate-700 border border-slate-600 hover:border-red-500 rounded text-slate-300 hover:text-red-400 transition-all"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="bg-black p-6">
                  <video
                    ref={modalVideoRef}
                    className="w-full rounded border border-slate-700"
                    controls
                    loop
                    autoPlay
                  >
                    <source
                      src="https://raw.githubusercontent.com/pauloeugenioreis/minikube-devops/main/minikube/docs/assets/autostart.webm"
                      type="video/webm"
                    />
                    Seu navegador não suporta vídeos WebM.
                  </video>
                </div>
              </div>

              <p className="text-center text-slate-400 text-sm mt-4">
                Clique fora do vídeo ou pressione ESC para
                fechar
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </SlideContainer>
  );
}