import { SlideContainer } from '../SlideContainer';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, FolderTree, Terminal, PlayCircle, Maximize2, X } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';

export function Slide11() {
  const [isExpanded, setIsExpanded] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const modalVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = 2.0;
    }
  }, []);

  useEffect(() => {
    if (isExpanded && modalVideoRef.current) {
      modalVideoRef.current.playbackRate = 2.0;
    }
  }, [isExpanded]);

  return (
    <SlideContainer background="dark">
      <div className="space-y-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl text-white text-center"
        >
          <span className="text-blue-400">Execução assistida (3):</span> Demonstrar a "execução" de CHECKLIST pelo Agent
        </motion.h2>

        {/* Quarta Interação - CHECKLIST */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-3"
        >
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-green-400" />
            <span className="text-green-400">Paulo Eugenio:</span>
          </div>
          
          <div className="bg-green-900/20 border border-green-500/50 rounded-lg p-2.5">
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <span className="text-lg flex-shrink-0">✅</span>
                <p className="text-slate-200 text-xs">
                  <strong className="text-green-300">4 - "Executar" CHECKLIST item 2</strong>
                </p>
              </div>

              <div className="bg-slate-900/50 border border-purple-500/30 rounded p-2 ml-6">
                <div className="flex items-center gap-1.5 mb-1.5">
                  <span className="text-sm">☁️</span>
                  <h4 className="text-purple-300 text-xs">2. VERSIONAMENTO GIT/GITHUB (OBRIGATÓRIO)</h4>
                </div>
                
                <div className="space-y-0.5 pl-5">
                  <div className="flex items-start gap-1.5 text-xs">
                    <span className="text-slate-500 text-xs">☐</span>
                    <p className="text-slate-300"><strong>git add .</strong></p>
                  </div>
                  <div className="flex items-start gap-1.5 text-xs">
                    <span className="text-slate-500 text-xs">☐</span>
                    <p className="text-slate-300"><strong>git commit -m "Descrição da alteração"</strong></p>
                  </div>
                  <div className="flex items-start gap-1.5 text-xs">
                    <span className="text-slate-500 text-xs">☐</span>
                    <p className="text-slate-300"><strong>git push</strong></p>
                  </div>
                  <div className="flex items-start gap-1.5 text-xs">
                    <span className="text-slate-500 text-xs">☐</span>
                    <p className="text-slate-300"><strong>Confirme que o repositório remoto está atualizado</strong></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Vídeo Demonstração */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-3"
        >
          <div className="flex items-center gap-2">
            <PlayCircle className="w-5 h-5 text-blue-400" />
            <span className="text-blue-400">Vídeo demonstrando:</span>
          </div>

          <div className="bg-slate-900/50 border border-blue-500/50 rounded-lg overflow-hidden shadow-2xl shadow-blue-500/20 max-w-3xl mx-auto">
            <div className="bg-slate-800 px-4 py-2 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-blue-400" />
                <span className="text-slate-300 text-sm">Agent executando CHECKLIST automaticamente</span>
              </div>
              <button
                onClick={() => setIsExpanded(true)}
                className="flex items-center gap-1.5 px-2 py-1 bg-slate-700/50 hover:bg-slate-700 border border-slate-600 hover:border-blue-500 rounded text-slate-300 hover:text-blue-400 transition-all"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span className="text-xs">Expandir</span>
              </button>
            </div>
            
            <div className="bg-black p-3">
              <video 
                ref={videoRef}
                className="w-full h-48 rounded border border-slate-700 object-cover"
                controls
                loop
                muted
                autoPlay
              >
                <source 
                  src="https://raw.githubusercontent.com/pauloeugenioreis/juntos-colaborar/main/docs/assets/video3.webm" 
                  type="video/webm" 
                />
                Seu navegador não suporta vídeos WebM.
              </video>
            </div>
          </div>
        </motion.div>

        {/* Resultado */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="grid grid-cols-3 gap-4 max-w-3xl mx-auto"
        >
          <div className="bg-gradient-to-r from-blue-900/30 to-cyan-900/30 border border-blue-500/50 rounded-lg p-4">
            <div className="flex flex-col items-center text-center">
              <span className="text-2xl mb-2">📋</span>
              <h3 className="text-blue-300 text-sm mb-1">CHECKLIST</h3>
              <p className="text-xs text-slate-400">Executado</p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 border border-purple-500/50 rounded-lg p-4">
            <div className="flex flex-col items-center text-center">
              <FolderTree className="w-7 h-7 text-purple-400 mb-2" />
              <h3 className="text-purple-300 text-sm mb-1">Estrutura</h3>
              <p className="text-xs text-slate-400">Padronizada</p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border border-green-500/50 rounded-lg p-4">
            <div className="flex flex-col items-center text-center">
              <span className="text-2xl mb-2">✅</span>
              <h3 className="text-green-300 text-sm mb-1">Automático</h3>
              <p className="text-xs text-slate-400">100% Agent</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Modal de Vídeo Expandido */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-8"
            onClick={() => setIsExpanded(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-6xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="bg-slate-900 border border-blue-500/50 rounded-lg overflow-hidden shadow-2xl">
                <div className="bg-slate-800 px-6 py-4 border-b border-slate-700 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Terminal className="w-5 h-5 text-blue-400" />
                    <span className="text-slate-300">
                      Agent executando CHECKLIST automaticamente
                    </span>
                  </div>
                  <button
                    onClick={() => setIsExpanded(false)}
                    className="flex items-center justify-center w-8 h-8 bg-slate-700/50 hover:bg-slate-700 border border-slate-600 hover:border-red-500 rounded text-slate-300 hover:text-red-400 transition-all"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="bg-black p-6">
                  <video
                    ref={modalVideoRef}
                    className="w-full rounded border border-slate-700"
                    controls
                    loop
                    autoPlay
                  >
                    <source
                      src="https://raw.githubusercontent.com/pauloeugenioreis/juntos-colaborar/main/docs/assets/video3.webm"
                      type="video/webm"
                    />
                    Seu navegador não suporta vídeos WebM.
                  </video>
                </div>
              </div>

              <p className="text-center text-slate-400 text-sm mt-4">
                Clique fora do vídeo ou pressione ESC para fechar
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </SlideContainer>
  );
}
