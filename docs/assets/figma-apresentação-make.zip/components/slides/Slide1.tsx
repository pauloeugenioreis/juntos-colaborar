import { SlideContainer } from "../SlideContainer";
import { Zap, Code, Brain, Sparkles } from "lucide-react";
import { motion } from "motion/react";

export function Slide1() {
  return (
    <SlideContainer background="gradient">
      <div className="space-y-12">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-4"
        >
          <div className="inline-flex items-center gap-3 bg-green-500/20 border border-green-500/50 rounded-full px-6 py-3">
            <Zap className="w-6 h-6 text-green-400" />
            <span className="text-green-400">A Virada</span>
          </div>

          <h2 className="text-5xl text-white">
            Agent de IA integrados à{" "}
            <span className="text-green-400">IDE</span>
          </h2>

          <p className="text-xl text-slate-400">
            Transformando produtividade com inteligência
            artificial
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="relative"
        >
          <div className="bg-slate-900/80 backdrop-blur border border-slate-700 rounded-xl p-8">
            <div className="grid grid-cols-3 gap-8 text-center">
              <div className="space-y-3">
                <div className="w-16 h-16 mx-auto rounded-full bg-blue-500/20 flex items-center justify-center">
                  <Code className="w-8 h-8 text-blue-400" />
                </div>
                <h3 className="text-xl text-white">
                  Geração de Código
                </h3>
                <p className="text-slate-400">
                  Do prompt ao código funcional
                </p>
              </div>

              <div className="space-y-3">
                <div className="w-16 h-16 mx-auto rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Brain className="w-8 h-8 text-purple-400" />
                </div>
                <h3 className="text-xl text-white">
                  Contexto Inteligente
                </h3>
                <p className="text-slate-400">
                  Entende sua arquitetura
                </p>
              </div>

              <div className="space-y-3">
                <div className="w-16 h-16 mx-auto rounded-full bg-green-500/20 flex items-center justify-center">
                  <Sparkles className="w-8 h-8 text-green-400" />
                </div>
                <h3 className="text-xl text-white">
                  Boas Práticas
                </h3>
                <p className="text-slate-400">
                  Padrões enterprise de forma automática,
                  consistente e documentação sempre atualizada
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </SlideContainer>
  );
}