import { ReactNode } from 'react';

interface SlideContainerProps {
  children: ReactNode;
  className?: string;
  background?: 'dark' | 'gradient' | 'light';
}

export function SlideContainer({ children, className = '', background = 'dark' }: SlideContainerProps) {
  const bgClasses = {
    dark: 'bg-slate-950',
    gradient: 'bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950',
    light: 'bg-slate-900',
  };

  return (
    <div className={`w-full h-screen flex items-center justify-center ${bgClasses[background]} ${className}`}>
      <div className="w-full h-full max-w-7xl mx-auto p-12 flex flex-col justify-center">
        {children}
      </div>
    </div>
  );
}
