import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
} from "lucide-react";
import { Slide1 } from "./components/slides/Slide1";
import { Slide2 } from "./components/slides/Slide2";
import { Slide3 } from "./components/slides/Slide3";
import { Slide4 } from "./components/slides/Slide4";
import { Slide5 } from "./components/slides/Slide5";
import { Slide6 } from "./components/slides/Slide6";
import { Slide7 } from "./components/slides/Slide7";
import { Slide8 } from "./components/slides/Slide8";
import { Slide9 } from "./components/slides/Slide9";
import { Slide10 } from "./components/slides/Slide10";
import { Slide11 } from "./components/slides/Slide11";
import { Slide12 } from "./components/slides/Slide12";
import { Slide13 } from "./components/slides/Slide13";

const slides = [
  Slide1,
  Slide2,
  Slide3,
  Slide4,
  Slide5,
  Slide6,
  Slide7,
  Slide8,
  Slide9,
  Slide10,
  Slide11,
  Slide12,
  Slide13,
];

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [direction, setDirection] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setDirection(1);
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setDirection(-1);
      setCurrentSlide(currentSlide - 1);
    }
  };

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch (error) {
      // Fullscreen not supported or not allowed in this environment
      console.log("Fullscreen not available");
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === " ") {
        e.preventDefault();
        nextSlide();
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        prevSlide();
      } else if (e.key === "f" || e.key === "F") {
        e.preventDefault();
        toggleFullscreen();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () =>
      window.removeEventListener("keydown", handleKeyDown);
  }, [currentSlide]);

  const CurrentSlideComponent = slides[currentSlide];

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
    }),
    center: {
      x: 0,
      opacity: 1,
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
    }),
  };

  return (
    <div className="relative w-full h-screen bg-slate-950 overflow-hidden">
      <AnimatePresence
        initial={false}
        custom={direction}
        mode="wait"
      >
        <motion.div
          key={currentSlide}
          custom={direction}
          variants={slideVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 },
          }}
          className="absolute inset-0"
        >
          <CurrentSlideComponent />
        </motion.div>
      </AnimatePresence>

      {/* Navigation Controls */}
      <div className="absolute bottom-8 left-0 right-0 flex items-center justify-center gap-6 z-10">
        <button
          onClick={prevSlide}
          disabled={currentSlide === 0}
          className="w-12 h-12 rounded-full bg-slate-800/80 backdrop-blur border border-slate-700 hover:border-blue-500 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center transition-colors"
        >
          <ChevronLeft className="w-6 h-6 text-slate-300" />
        </button>

        {/* Progress Indicator */}
        <div className="flex items-center gap-2 px-6 py-3 rounded-full bg-slate-800/80 backdrop-blur border border-slate-700">
          <span className="text-white text-sm">
            {currentSlide + 1}
          </span>
          <span className="text-slate-500 text-sm">/</span>
          <span className="text-slate-400 text-sm">
            {slides.length}
          </span>

          <div className="ml-4 flex gap-1">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => {
                  setDirection(index > currentSlide ? 1 : -1);
                  setCurrentSlide(index);
                }}
                className="group"
              >
                <div
                  className={`h-1 transition-all ${
                    index === currentSlide
                      ? "w-8 bg-blue-500"
                      : "w-1 bg-slate-600 group-hover:bg-slate-500"
                  } rounded-full`}
                />
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={nextSlide}
          disabled={currentSlide === slides.length - 1}
          className="w-12 h-12 rounded-full bg-slate-800/80 backdrop-blur border border-slate-700 hover:border-blue-500 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center transition-colors"
        >
          <ChevronRight className="w-6 h-6 text-slate-300" />
        </button>
      </div>
    </div>
  );
}